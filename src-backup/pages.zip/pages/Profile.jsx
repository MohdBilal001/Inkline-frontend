import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { getAuthorByUsername, getArticlesByUsername } from '../api/client'
import Avatar from '../components/Avatar'
import ArticleCard from '../components/ArticleCard'

export default function Profile() {
  const { username } = useParams()
  const [author, setAuthor] = useState(null)
  const [articles, setArticles] = useState([])
  const [status, setStatus] = useState('loading') // loading | ready | not-found

  useEffect(() => {
    let cancelled = false
    setStatus('loading')
    getAuthorByUsername(username)
      .then(async (authorData) => {
        if (cancelled) return
        setAuthor(authorData)
        const theirArticles = await getArticlesByUsername(username)
        if (!cancelled) {
          setArticles(theirArticles)
          setStatus('ready')
        }
      })
      .catch(() => {
        if (!cancelled) setStatus('not-found')
      })
    return () => {
      cancelled = true
    }
  }, [username])

  if (status === 'loading') {
    return <div className="mx-auto max-w-measure px-6 py-16 text-muted font-sans">Loading…</div>
  }
  if (status === 'not-found' || !author) {
    return <div className="mx-auto max-w-measure px-6 py-16 text-muted font-sans">No writer found.</div>
  }

  return (
    <div className="mx-auto max-w-measure px-6 py-14">
      <div className="flex items-center gap-4 mb-4">
        <Avatar author={author} size={64} />
        <div>
          <h1 className="font-display text-3xl font-medium">{author.name}</h1>
          <p className="font-sans text-sm text-muted">@{author.username}</p>
        </div>
      </div>
      {author.bio && (
        <p className="font-serif text-ink-soft leading-relaxed mb-10 max-w-measure">{author.bio}</p>
      )}

      <h2 className="font-sans text-xs font-semibold uppercase tracking-wide text-muted mb-2">
        Published
      </h2>
      {articles.length === 0 && <p className="text-muted font-sans">No published stories yet.</p>}
      {articles.map((article) => (
        <ArticleCard key={article.id} article={article} author={article.author} />
      ))}
    </div>
  )
}
